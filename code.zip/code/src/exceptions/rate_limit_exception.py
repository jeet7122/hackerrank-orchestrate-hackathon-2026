class RateLimitException(Exception):
    pass